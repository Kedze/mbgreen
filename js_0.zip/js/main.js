document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    mobileMenuButton.addEventListener('click', function() {
        mobileMenu.classList.toggle('hidden');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!mobileMenuButton.contains(event.target) && !mobileMenu.contains(event.target)) {
            mobileMenu.classList.add('hidden');
        }
    });

    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Navigation scroll effect
    const nav = document.getElementById('main-nav');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll <= 0) {
            nav.classList.remove('nav-scroll');
        }
        if (currentScroll > lastScroll && currentScroll > 100) {
            nav.classList.add('-translate-y-full');
        } else {
            nav.classList.remove('-translate-y-full');
        }
        if (currentScroll > 100) {
            nav.classList.add('nav-scroll');
        }
        
        lastScroll = currentScroll;
    });

    // Animation observer
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('appear');
                observer.unobserve(entry.target); // Only animate once
            }
        });
    }, observerOptions);

    // Observe all elements with animation classes
    const animatedElements = document.querySelectorAll(
        '.fade-in, .slide-in-left, .slide-in-right, .scale-in'
    );
    
    animatedElements.forEach(el => observer.observe(el));

    // Optional: Add scroll-triggered animations for the navigation
    window.addEventListener('scroll', () => {
        const nav = document.getElementById('main-nav');
        if (window.scrollY > 100) {
            nav.classList.add('nav-scrolled');
        } else {
            nav.classList.remove('nav-scrolled');
        }
    });

    // Slideshow functionality
    initSlideshow();
});

function initSlideshow() {
    const slideshow = document.getElementById('hero-slideshow');
    if (!slideshow) {
        console.log('Slideshow element not found');
        return;
    }

    const slides = Array.from(slideshow.querySelectorAll('.slide'));
    const navButtons = Array.from(slideshow.querySelectorAll('.slide-nav'));
    
    if (slides.length === 0 || navButtons.length === 0) {
        console.log('Slides or navigation buttons not found');
        return;
    }

    let currentSlide = 0;
    let slideInterval;

    // Show a specific slide
    function showSlide(index) {
        // Remove active class from all slides and buttons
        slides.forEach(slide => slide.classList.remove('active'));
        navButtons.forEach(btn => btn.classList.remove('active'));

        // Add active class to current slide and button
        slides[index].classList.add('active');
        navButtons[index].classList.add('active');
        
        currentSlide = index;
    }

    // Show next slide
    function nextSlide() {
        const next = (currentSlide + 1) % slides.length;
        showSlide(next);
    }

    // Start slideshow
    function startSlideshow() {
        if (slideInterval) {
            clearInterval(slideInterval);
        }
        slideInterval = setInterval(nextSlide, 5000);
    }

    // Initialize first slide
    showSlide(0);

    // Add click handlers to navigation buttons
    navButtons.forEach((button, index) => {
        button.addEventListener('click', () => {
            clearInterval(slideInterval);
            showSlide(index);
            startSlideshow();
        });
    });

    // Pause on hover
    slideshow.addEventListener('mouseenter', () => {
        if (slideInterval) {
            clearInterval(slideInterval);
        }
    });

    slideshow.addEventListener('mouseleave', startSlideshow);

    // Start the slideshow
    startSlideshow();

    // Debug log
    console.log('Slideshow initialized with', slides.length, 'slides');
}

// Make sure the DOM is loaded before initializing
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing slideshow');
    initSlideshow();
}); 
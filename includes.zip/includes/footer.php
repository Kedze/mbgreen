    <footer class="bg-green-900 text-white pt-16 pb-8">
        <div class="max-w-7xl mx-auto px-4">
            <!-- Main Footer Content -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
                <!-- Company Info -->
                <div class="space-y-6">
                    <img src="images/logo.png" alt="MB GREEN AGRO CONSULT" 
                         class="h-16 w-auto mb-4">
                    <p class="text-gray-300">
                    Our commitment to excellence, sustainability, and capacity-building has positioned us
                     as a leading provider of agribusiness solutions, empowering local farmers and agribusinesses
                      to achieve long-term success.
                    </p>
                    <div class="flex space-x-4">
                        <a href="https://www.facebook.com/people/MB-Green-Agro-Consult/61573005193635/?mibextid=ZbWKwL" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-facebook-f text-xl"></i>
                        </a>
                        <a href="https://x.com/MBGAgroConsult?t=NfLwnXxDfhpE_pxO5TPyRg&s=09" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-twitter text-xl"></i>
                        </a>
                        
                        <a href="https://www.instagram.com/mbgreenagroconsult/?utm_source=qr&r=nametag" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-instagram text-xl"></i>
                        </a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div>
                    <h3 class="text-xl font-bold mb-6">Quick Links</h3>
                    <ul class="space-y-4">
                        <li>
                            <a href="about.php" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>About Us
                            </a>
                        </li>
                        <li>
                            <a href="services.php" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Our Services
                            </a>
                        </li>
                        <li>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Projects
                            </a>
                        </li>
                        <li>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Blog & News
                            </a>
                        </li>
                        <li>
                            <a href="contact.php" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Contact Us
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Services -->
                <div>
                    <h3 class="text-xl font-bold mb-6">Our Services</h3>
                    <ul class="space-y-4">
                        <li>
                            <a href="services.php#consulting" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Agricultural Consulting
                            </a>
                        </li>
                        <li>
                            <a href="services.php#management" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Farm Management
                            </a>
                        </li>
                        <li>
                            <a href="services.php#training" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Training Programs
                            </a>
                        </li>
                        <li>
                            <a href="services.php#inputs" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Agro Input Distribution
                            </a>
                        </li>
                        <li>
                            <a href="services.php#agroforestry" class="text-gray-300 hover:text-white transition-colors flex items-center">
                                <i class="fas fa-chevron-right mr-2 text-sm"></i>Agroforestry Solutions
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Contact Info -->
                <div>
                    <h3 class="text-xl font-bold mb-6">Get in Touch</h3>
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <i class="fas fa-map-marker-alt mt-1.5 mr-3 text-green-400"></i>
                            <p class="text-gray-300">
                                Cecilia Johnson Street<br>
                                BS-0035-6147 Sunyani,<br>
                                Ghana
                            </p>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-phone mr-3 text-green-400"></i>
                            <p class="text-gray-300">054 174 9791 | 024 473 2512</p>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-envelope mr-3 text-green-400"></i>
                            <p class="text-gray-300">info@mbgreenagroconsult.com</p>
                        </div>
                        <div class="flex items-start">
                            <i class="fas fa-clock mt-1.5 mr-3 text-green-400"></i>
                            <div class="text-gray-300">
                                <p>Monday - Friday: 8:00 AM - 5:00 PM</p>
                                <p>Saturday: 9:00 AM - 2:00 PM</p>
                                <p>Sunday: Closed</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Newsletter Subscription -->
            <div class="border-t border-green-800 pt-8 pb-12">
                <div class="max-w-2xl mx-auto text-center">
                    <h3 class="text-xl font-bold mb-4">Subscribe to Our Newsletter</h3>
                    <p class="text-gray-300 mb-6">Stay updated with our latest news and updates in agriculture</p>
                    <form class="flex flex-col sm:flex-row gap-4 justify-center">
                        <input type="email" placeholder="Enter your email" 
                               class="px-4 py-3 rounded-lg bg-green-800 text-white placeholder-gray-400 border border-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 flex-grow max-w-md">
                        <button type="submit" 
                                class="px-6 py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-500 transition-colors">
                            Subscribe
                        </button>
                    </form>
                </div>
            </div>

            <!-- Bottom Footer -->
            <div class="border-t border-green-800 pt-8 mt-8">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <p class="text-gray-400 text-sm mb-4 md:mb-0">
                        &copy; <?php echo date('Y'); ?> MB GREEN AGRO CONSULT. All rights reserved.
                    </p>
                    <div class="flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
                        <a href="#" class="text-gray-400 hover:text-white text-sm">Terms of Service</a>
                        <a href="#" class="text-gray-400 hover:text-white text-sm">Cookie Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Polyfills for older browsers -->
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default,Array.prototype.includes,IntersectionObserver"></script>
    
    <script src="js/main.js"></script>
</body>
</html> 
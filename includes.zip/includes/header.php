<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="MB GREEN AGRO CONSULT - Your trusted partner in agricultural consulting and sustainable farming solutions">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#1f2937">
    <title>MB GREEN AGRO CONSULT - Championing Agribusiness</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="images/logo.png">
    
    <!-- Preconnect to external resources -->
    <link rel="preconnect" href="https://cdn.tailwindcss.com">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    
    <!-- Styles -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <!-- Cross-browser compatibility -->
    <script>
        // Add 'js' class to html element if JavaScript is enabled
        document.documentElement.className = document.documentElement.className.replace(/\bno-js\b/, 'js');
    </script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="fixed w-full z-50 transition-all duration-300 top-0" id="main-nav">
        <div class="bg-gray-800 shadow-md">
            <div class="max-w-7xl mx-auto px-4">
                <div class="flex justify-between items-center h-20">
                    <!-- Logo -->
                    <div class="flex items-center">
                        <a href="index.php" class="flex items-center logo-container">
                            <img src="images/logo_main.jpg" alt="MB GREEN AGRO CONSULT" 
                                 class="h-14 w-auto mr-3">
                            <div class="logo-text">
                                <span class="font-extrabold text-2xl tracking-wider text-white uppercase">
                                    MB <span class="text-green-400">Green</span>
                                </span>
                                <span class="font-bold text-lg tracking-widest text-white uppercase relative">
                                    Agro Consult
                                    <span class="absolute bottom-0 left-0 w-full h-0.5 bg-green-400 transform scale-x-0 transition-transform group-hover:scale-x-100"></span>
                                </span>
                            </div>
                        </a>
                    </div>
                    
                    <!-- Desktop Menu -->
                    <div class="hidden md:flex items-center space-x-1">
                        <a href="index.php" class="px-4 py-2 text-white hover:text-green-300 transition-colors rounded-lg <?php echo ($_SERVER['PHP_SELF'] == '/index.php' ? 'bg-gray-700' : ''); ?>">Home</a>
                        <a href="services.php" class="px-4 py-2 text-white hover:text-green-300 transition-colors rounded-lg <?php echo ($_SERVER['PHP_SELF'] == '/services.php' ? 'bg-gray-700' : ''); ?>">Services</a>
                        <a href="gallery.php" class="px-4 py-2 text-white hover:text-green-300 transition-colors rounded-lg <?php echo ($_SERVER['PHP_SELF'] == '/gallery.php' ? 'bg-gray-700' : ''); ?>">Gallery</a>
                        <a href="about.php" class="px-4 py-2 text-white hover:text-green-300 transition-colors rounded-lg <?php echo ($_SERVER['PHP_SELF'] == '/about.php' ? 'bg-gray-700' : ''); ?>">About</a>
                        <a href="contact.php" class="ml-2 px-6 py-2 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-500 transition-colors">Contact</a>
                    </div>

                    <!-- Mobile Menu Button -->
                    <div class="md:hidden">
                        <button id="mobile-menu-button" class="text-white hover:text-green-300 p-2">
                            <i class="fas fa-bars text-2xl"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-gray-800 shadow-md">
            <div class="px-4 py-3 space-y-1">
                <a href="index.php" class="block px-3 py-2 text-white hover:bg-gray-700 <?php echo ($_SERVER['PHP_SELF'] == '/index.php' ? 'bg-gray-700' : ''); ?>">Home</a>
                <a href="services.php" class="block px-3 py-2 text-white hover:bg-gray-700 <?php echo ($_SERVER['PHP_SELF'] == '/services.php' ? 'bg-gray-700' : ''); ?>">Services</a>
                <a href="gallery.php" class="block px-3 py-2 text-white hover:bg-gray-700 <?php echo ($_SERVER['PHP_SELF'] == '/gallery.php' ? 'bg-gray-700' : ''); ?>">Gallery</a>
                <a href="about.php" class="block px-3 py-2 text-white hover:bg-gray-700 <?php echo ($_SERVER['PHP_SELF'] == '/about.php' ? 'bg-gray-700' : ''); ?>">About</a>
                <a href="contact.php" class="block px-3 py-2 text-white hover:bg-gray-700 <?php echo ($_SERVER['PHP_SELF'] == '/contact.php' ? 'bg-gray-700' : ''); ?>">Contact</a>
            </div>
        </div>
    </nav>

    <?php
    // Display success/error messages if they exist
    if (isset($_GET['status'])) {
        $status = $_GET['status'];
        $messages = isset($_GET['messages']) ? explode(',', urldecode($_GET['messages'])) : [];
        
        if ($status === 'success') {
            echo '<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative max-w-7xl mx-auto mt-4" role="alert">
                    <strong class="font-bold">Success!</strong>
                    <span class="block sm:inline"> Your message has been sent successfully.</span>
                </div>';
        } elseif ($status === 'error') {
            echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative max-w-7xl mx-auto mt-4" role="alert">
                    <strong class="font-bold">Error!</strong>';
            if (!empty($messages)) {
                foreach ($messages as $message) {
                    echo '<span class="block sm:inline"> ' . htmlspecialchars($message) . '</span>';
                }
            } else {
                echo '<span class="block sm:inline"> There was an error processing your request.</span>';
            }
            echo '</div>';
        }
    }
    ?> 
</body>
</html> 